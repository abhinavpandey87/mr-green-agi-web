import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>👋 Welcome to Mr. GREEN AGI</h1>
      <p>Chat interface coming soon...</p>
    </div>
  );
}

export default App;
